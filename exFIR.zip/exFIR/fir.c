#include "settings.h"

void FIR(DATATYPE * X, DATATYPE * Y, DATATYPE * b) {

    for (int t = 0; t < SIZE; t++) {
        Y[t] = (DATATYPE) 0;
        if (t >= N) {
            for(int n = 0; n <= N; n++)
                Y[t] += b[n] * X[t - n];
        }
    }

}