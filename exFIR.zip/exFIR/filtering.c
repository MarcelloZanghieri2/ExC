/*

Realizzare un filtro FIR in base alle seguenti specifiche.

1. Rivedere la definizione di filtro FIR:
   https://en.m.wikipedia.org/wiki/Finite_impulse_response .
2. Implementare il filtro sulla virtual platform di PULP creando un nuovo
   progetto.
   - Allocare tutti i dati in L1 (coefficienti coeff, input In, output Out).
   - Definire tre parametri con direttive #define:
     - SIZE dimensione dei vettori
     - N dimensione del filtro
     - DATATYPE tipo dei dati (float, int, short...).
   - Mettere le costanti in un file settings.h da includere negli altri file.
   - Creare una funzione con nome FIR e parametri X, Y e b nei file fir.c e
     fir.h.
   - Per testare il codice eseguire la funzione sul fabric controller (senza
     accendere il cluster) usando 16 valori e 4 coefficienti (inizializzati in
     un qualsiasi modo) e verificare con matlab o manualmente che il risultato
     sia corretto.
3. Accendere il cluster ed eseguire il codice su un core del cluster.
4. Parallelizzare su 1, 2, 4, 8 core.
5. Effettuare misurazioni per tutte le configurazioni implementate, usando una
   o più #define per passare da una all'altra, usando SIZE 256 e 1024.

*/



#include <stdio.h>
#include "settings.h"
#include "fir.h"


int main() {

    DATATYPE X[SIZE] = {3, 0, 0, 1, 1, 1, 5, 5, 5, 2, 2, -4};
    DATATYPE Y[SIZE], b[N + 1] = {1, -1, 0, 0};
    
    FIR(X, Y, b);

    printf("\n\n");
    for (int t = 0; t < SIZE; t++)
        printf("%.1Lf\t ", Y[t]);
    printf("\n\n");
    
    return 0;
}