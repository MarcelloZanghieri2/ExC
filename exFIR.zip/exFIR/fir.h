#include "settings.h"

void FIR(DATATYPE * X, DATATYPE * Y, DATATYPE * b);